///////////////////////////////////////////////////////////////////////////////
//
// File           : $Workfile: MSWinSock.cpp $
// Version        : $Revision: 4 $
// Function       : 
//
// Author         : $Author: Len $
// Date           : $Date: 29/06/02 5:13 $
//
// Notes          : 
//
// Modifications  :
//
// $Log: /Web Articles/SocketServers/EchoServerEx/JetByteTools/Win32Tools/MSWinSock.cpp $
// 
// 4     29/06/02 5:13 Len
// Allow DisconnectSocketForReuse() to be called async.
// 
// 3     29/05/02 11:16 Len
// Lint issues.
// 
// 2     29/05/02 9:22 Len
// Fixed exceptions.
// 
// 1     28/05/02 15:09 Len
// 
///////////////////////////////////////////////////////////////////////////////
//
// Copyright 1997 - 2002 JetByte Limited.
//
// JetByte Limited grants you ("Licensee") a non-exclusive, royalty free, 
// licence to use, modify and redistribute this software in source and binary 
// code form, provided that i) this copyright notice and licence appear on all 
// copies of the software; and ii) Licensee does not utilize the software in a 
// manner which is disparaging to JetByte Limited.
//
// This software is provided "as is" without a warranty of any kind. All 
// express or implied conditions, representations and warranties, including
// any implied warranty of merchantability, fitness for a particular purpose
// or non-infringement, are hereby excluded. JetByte Limited and its licensors 
// shall not be liable for any damages suffered by licensee as a result of 
// using, modifying or distributing the software or its derivatives. In no
// event will JetByte Limited be liable for any lost revenue, profit or data,
// or for direct, indirect, special, consequential, incidental or punitive
// damages, however caused and regardless of the theory of liability, arising 
// out of the use of or inability to use software, even if JetByte Limited 
// has been advised of the possibility of such damages.
//
// This software is not designed or intended for use in on-line control of 
// aircraft, air traffic, aircraft navigation or aircraft communications; or in 
// the design, construction, operation or maintenance of any nuclear 
// facility. Licensee represents and warrants that it will not use or 
// redistribute the Software for such purposes. 
//
///////////////////////////////////////////////////////////////////////////////

#include "MSWinSock.h"

#include "Utils.h"

///////////////////////////////////////////////////////////////////////////////
// Namespace: JetByteTools::Win32
///////////////////////////////////////////////////////////////////////////////

namespace JetByteTools {
namespace Win32 {

///////////////////////////////////////////////////////////////////////////////
// Static helper functions
///////////////////////////////////////////////////////////////////////////////

static bool LoadExtensionFunction(
   SOCKET s,
   GUID functionID,
   void **ppFunc);

///////////////////////////////////////////////////////////////////////////////
// Static members variables
///////////////////////////////////////////////////////////////////////////////

LPFN_ACCEPTEX CMSWinSock::pAcceptEx = 0;
LPFN_GETACCEPTEXSOCKADDRS CMSWinSock::pGetAcceptExSockaddrs = 0;
LPFN_DISCONNECTEX CMSWinSock::pDisconnectEx = 0;
LPFN_TRANSMITFILE CMSWinSock::pTransmitFile = 0;

///////////////////////////////////////////////////////////////////////////////
// CMSWinSock
///////////////////////////////////////////////////////////////////////////////

bool CMSWinSock::AcceptEx(
         SOCKET listenSocket,
         SOCKET acceptSocket,
         PVOID pOutputBuffer,
         DWORD receiveDataLength,
         DWORD localAddressLength,
         DWORD remoteAddressLength,
         LPDWORD bytesReceived,
         LPOVERLAPPED pOverlapped)
{
   if (!pAcceptEx && !LoadAcceptEx(listenSocket))
   {
      throw Exception(_T("CMSWinSock::AcceptEx()"), _T("Failed to load extension function"));
   }

   if (!pGetAcceptExSockaddrs)
   {
      // Since we cant demand load in the call to GetAcceptExSockaddrs as we
      // dont have a socket there, do it here instead...

      //lint -e{534} ignoring return value
      LoadGetAcceptExSockaddrs(listenSocket);
   }
    
   return BOOL_to_bool(pAcceptEx(
      listenSocket, 
      acceptSocket, 
      pOutputBuffer, 
      receiveDataLength, 
      localAddressLength, 
      remoteAddressLength,       
      bytesReceived,
      pOverlapped));
}

bool CMSWinSock::LoadAcceptEx(SOCKET s)
{
   if (pAcceptEx)
   {
      return true;
   }

   GUID guidAcceptEx = WSAID_ACCEPTEX;

   //lint -e{741} Unusual pointer cast (function qualification)
   return LoadExtensionFunction(s, guidAcceptEx, (void**)&pAcceptEx);
}

void CMSWinSock::GetAcceptExSockaddrs(
   PVOID pOutputBuffer,       
   DWORD receiveDataLength,  
   DWORD localAddressLength,  
   DWORD remoteAddressLength,  
   LPSOCKADDR *ppLocalSockaddr,  
   LPINT pLocalSockaddrLength,  
   LPSOCKADDR *ppRemoteSockaddr,  
   LPINT pRemoteSockaddrLength)
{
   if (!pGetAcceptExSockaddrs)
   {
      throw Exception(_T("CMSWinSock::GetAcceptExSockaddrs()"), _T("Extension function not loaded"));
   }

   pGetAcceptExSockaddrs(
      pOutputBuffer,       
      receiveDataLength,  
      localAddressLength,  
      remoteAddressLength,  
      ppLocalSockaddr,  
      pLocalSockaddrLength,  
      ppRemoteSockaddr,  
      pRemoteSockaddrLength);
}

bool CMSWinSock::LoadGetAcceptExSockaddrs(
   SOCKET s)
{
   if (pGetAcceptExSockaddrs)
   {
      return true;
   }

   GUID guidGetAcceptExSockaddrs = WSAID_GETACCEPTEXSOCKADDRS;

   //lint -e{741} Unusual pointer cast (function qualification)
   return LoadExtensionFunction(s, guidGetAcceptExSockaddrs, (void**)&pGetAcceptExSockaddrs);
}

bool CMSWinSock::DisconnectEx(
   SOCKET s,
   LPOVERLAPPED pOverlapped,
   DWORD flags)
{
   if (!pDisconnectEx && !LoadDisconnectEx(s))
   {
      throw Exception(_T("CMSWinSock::DisconnectEx()"), _T("Failed to load extension function"));
   }
    
   return BOOL_to_bool(pDisconnectEx(s, pOverlapped, flags, 0));
}

bool CMSWinSock::LoadDisconnectEx(
   SOCKET s)
{
   if (pDisconnectEx)
   {
      return true;
   }

   GUID guidDisconnectEx = WSAID_DISCONNECTEX;

   //lint -e{741} Unusual pointer cast (function qualification)
   return LoadExtensionFunction(s, guidDisconnectEx, (void**)&pDisconnectEx);
}

bool CMSWinSock::TransmitFile(
   SOCKET s,
   HANDLE fileToTransmit,
   DWORD numberOfBytesToWrite,
   DWORD numberOfBytesPerSend,
   LPOVERLAPPED pOverlapped,
   LPTRANSMIT_FILE_BUFFERS pTransmitBuffers,
   DWORD flags)
{
   if (!pTransmitFile && !LoadTransmitFile(s))
   {
      throw Exception(_T("CMSWinSock::TransmitFile()"), _T("Failed to load extension function"));
   }
    
   return BOOL_to_bool(pTransmitFile(
      s, 
      fileToTransmit,
      numberOfBytesToWrite,
      numberOfBytesPerSend,
      pOverlapped,
      pTransmitBuffers,
      flags));
}

bool CMSWinSock::LoadTransmitFile(
   SOCKET s)
{
   if (pTransmitFile)
   {
      return true;
   }

   GUID guidTransmitFile = WSAID_TRANSMITFILE;

   //lint -e{741} Unusual pointer cast (function qualification)
   return LoadExtensionFunction(s, guidTransmitFile, (void**)&pTransmitFile);
}

bool CMSWinSock::DisconnectSocketForReuse(
   SOCKET s,
   LPOVERLAPPED pOverlapped)
{
   if (pDisconnectEx)
   {
      Output(_T("DisconnectSocketForReuse - DisconnectEx"));
      return DisconnectEx(s, pOverlapped, TF_REUSE_SOCKET);
   }

   if (pTransmitFile)
   {
      Output(_T("DisconnectSocketForReuse - TransmitFile"));
      return TransmitFile(s, 0, 0, 0, pOverlapped, 0, TF_DISCONNECT | TF_REUSE_SOCKET );
   }

   if (CanDisconnectSocketForReuse(s))
   {
      return DisconnectSocketForReuse(s, pOverlapped);
   }

   throw Exception(_T("CMSWinSock::DisconnectSocketForReuse()"), _T("Failed to load extension function"));
}

bool CMSWinSock::CanDisconnectSocketForReuse(
   SOCKET s)
{
   if (pDisconnectEx || pTransmitFile)
   {
      return true;
   }

   if (LoadDisconnectEx(s))
   {
      return true;
   }

   return LoadTransmitFile(s);
}

///////////////////////////////////////////////////////////////////////////////
// CMSWinSock::Exception
///////////////////////////////////////////////////////////////////////////////

CMSWinSock::Exception::Exception(
   const _tstring &where, 
   const _tstring &what)
   : CException(where, what)
{
}

///////////////////////////////////////////////////////////////////////////////
// Static helper functions
///////////////////////////////////////////////////////////////////////////////

static bool LoadExtensionFunction(
   SOCKET s,
   GUID functionID,
   void **ppFunc)
{
   DWORD dwBytes = 0;

   bool ok = true;

   if (0 != WSAIoctl(
      s, 
      SIO_GET_EXTENSION_FUNCTION_POINTER,
      &functionID,
      sizeof(GUID),
      ppFunc,
      sizeof(void *),
      &dwBytes,
      0,
      0))
   {
      ok = false;
   }

   return ok;
}

///////////////////////////////////////////////////////////////////////////////
// Namespace: JetByteTools::Win32
///////////////////////////////////////////////////////////////////////////////

} // End of namespace Win32
} // End of namespace JetByteTools 

///////////////////////////////////////////////////////////////////////////////
// End of file
///////////////////////////////////////////////////////////////////////////////

