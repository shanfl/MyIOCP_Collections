///////////////////////////////////////////////////////////////////////////////
//
// File           : $Workfile: SocketServerEx.cpp $
// Version        : $Revision: 11 $
// Function       : 
//
// Author         : $Author: Len $
// Date           : $Date: 19/07/02 11:29 $
//
// Notes          : 
//
// Modifications  :
//
// $Log: /Web Articles/SocketServers/EchoServerEx/JetByteTools/Win32Tools/SocketServerEx.cpp $
// 
// 11    19/07/02 11:29 Len
// Bug fix: Reenabled the socket pooling code that had been commented out
// for testing.
// 
// 10    19/07/02 11:21 Len
// Merged in changes from latest Socket Server code.
// 
// 9     1/07/02 12:31 Len
// Moved all callbacks to the SocketServer class. We now provide a default
// implementation for the WorkerThread. This raises its events via the
// socket server. The user now only has to provide one derived class
// rather than two. We now provide a default implementation for listening
// socket creation.
// 
// 8     29/06/02 6:46 Len
// Reset socket flags when reusing socket
// 
// 7     29/06/02 5:13 Len
// Integrated the socket closure changes from the non EX version of the
// socket server.
// 
// 6     7/06/02 14:29 Len
// Changes due to change in CIOBuffer. The buffer now derives from
// OVERLAPPED so the explicit conversion functions are no longer required.
// 
// 5     29/05/02 12:04 Len
// More lint issues.
// 
// 4     29/05/02 11:16 Len
// Lint issues.
// 
// 3     29/05/02 10:08 Len
// Refactored the socket connection time stuff.
// Fixed socket reference counting issues.
// Handle accepts that complete without data when a read was requested
// (this happens when an accept should read data but the connection is
// terminated after it's established but before it sends data).
// 
// 2     28/05/02 18:50 Len
// When posting the results of the synchronous  completion of an AcceptEx
// call to the iocp we should pass the listening socket as the completion
// key so that the semantics are the same as an asynchronously generated
// completion.
// 
// 1     28/05/02 15:09 Len
// 
///////////////////////////////////////////////////////////////////////////////
//
// Copyright 1997 - 2002 JetByte Limited.
//
// JetByte Limited grants you ("Licensee") a non-exclusive, royalty free, 
// licence to use, modify and redistribute this software in source and binary 
// code form, provided that i) this copyright notice and licence appear on all 
// copies of the software; and ii) Licensee does not utilize the software in a 
// manner which is disparaging to JetByte Limited.
//
// This software is provided "as is" without a warranty of any kind. All 
// express or implied conditions, representations and warranties, including
// any implied warranty of merchantability, fitness for a particular purpose
// or non-infringement, are hereby excluded. JetByte Limited and its licensors 
// shall not be liable for any damages suffered by licensee as a result of 
// using, modifying or distributing the software or its derivatives. In no
// event will JetByte Limited be liable for any lost revenue, profit or data,
// or for direct, indirect, special, consequential, incidental or punitive
// damages, however caused and regardless of the theory of liability, arising 
// out of the use of or inability to use software, even if JetByte Limited 
// has been advised of the possibility of such damages.
//
// This software is not designed or intended for use in on-line control of 
// aircraft, air traffic, aircraft navigation or aircraft communications; or in 
// the design, construction, operation or maintenance of any nuclear 
// facility. Licensee represents and warrants that it will not use or 
// redistribute the Software for such purposes. 
//
///////////////////////////////////////////////////////////////////////////////

#include "SocketServerEx.h"
#include "IOCompletionPort.h"
#include "Win32Exception.h"
#include "Utils.h"
#include "SystemInfo.h"
#include "Socket.h"

#include <vector>

#include "MsWinSock.h"

#pragma comment(lib, "ws2_32.lib")

///////////////////////////////////////////////////////////////////////////////
// Lint options
//
//lint -save
//
// Default constructor implicitly called
//lint -esym(1926, CSocketServerEx::m_listManipulationSection)
//lint -esym(1926, CSocketServerEx::m_activeList)
//lint -esym(1926, CSocketServerEx::m_freeList)
//lint -esym(1926, CSocketServerEx::m_pendingList)
//lint -esym(1926, CSocketServerEx::m_shutdownEvent)
//lint -esym(1926, CSocketServerEx::m_acceptConnectionsEvent)
//lint -esym(1926, CSocketServerEx::m_postMoreAcceptsEvent)
//lint -esym(1926, CSocketServerEx::m_stopAcceptingConnectionsEvent)
//lint -esym(1926, CSocketServerEx::m_acceptEvent)
//
// Symbol did not appear in the constructor initializer list
//lint -esym(1928, CThread)
//lint -esym(1928, CUsesWinsock)
//lint -esym(1928, Node)
//lint -esym(1928, COpaqueUserData)
//
// Member not defined
//lint -esym(1526, CSocketServerEx::CSocketServerEx)
//lint -esym(1526, CSocketServerEx::operator=)
//lint -esym(1526, Socket::Socket)
//lint -esym(1526, Socket::operator=)
//lint -esym(1526, WorkerThread::WorkerThread)
//lint -esym(1526, WorkerThread::operator=)
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// Using directives
///////////////////////////////////////////////////////////////////////////////

using std::vector;

///////////////////////////////////////////////////////////////////////////////
// Namespace: JetByteTools::Win32
///////////////////////////////////////////////////////////////////////////////

namespace JetByteTools {
namespace Win32 {

///////////////////////////////////////////////////////////////////////////////
// Static helper methods
///////////////////////////////////////////////////////////////////////////////

static size_t CalculateNumberOfThreads(
   size_t numThreads);

///////////////////////////////////////////////////////////////////////////////
// CSocketServerEx
///////////////////////////////////////////////////////////////////////////////

CSocketServerEx::CSocketServerEx(
   unsigned long addressToListenOn,
   unsigned short portToListenOn,
   size_t maxFreeSockets,
   size_t maxFreeBuffers,
   size_t acceptsToPost,
   bool readDataOnAccept,
   size_t acceptReadTimeoutSeconds /* = 5*/,
   size_t bufferSize /* = 1024 */,
   size_t numThreads /* = 0 */,
   bool useSequenceNumbers /* = true */,
   bool postZeroByteReads /* = false */)
   :  CIOBuffer::Allocator(bufferSize, maxFreeBuffers),
      m_numThreads(CalculateNumberOfThreads(numThreads)),
      m_listeningSocket(INVALID_SOCKET),
      m_iocp(0),
      m_address(addressToListenOn),
      m_port(portToListenOn),
      m_maxFreeSockets(maxFreeSockets),
      m_acceptsToPost(acceptsToPost),
      m_acceptsPending(0),
      m_acceptReadTimeoutSeconds(acceptReadTimeoutSeconds),
      m_readDataOnAccept(readDataOnAccept),
      m_useSequenceNumbers(useSequenceNumbers),
      m_postZeroByteReads(postZeroByteReads)
{
}

CSocketServerEx::~CSocketServerEx()
{
}

void CSocketServerEx::ReleaseSockets()
{
   // Close all pending sockets

   CCriticalSection::Owner lock(m_listManipulationSection);

   Socket *pSocket = m_pendingList.Head();

   while (pSocket)
   {
      Socket *pNext = SocketList::Next(pSocket);

      pSocket->Close();

      pSocket = pNext;
   }

   // Close all active sockets

   pSocket = m_activeList.Head();

   while (pSocket)
   {
      Socket *pNext = SocketList::Next(pSocket);

      pSocket->Close();

      pSocket = pNext;
   }

   // release any remaining active sockets     

   while (m_activeList.Head())
   {
      ReleaseSocket(m_activeList.Head());
   }

   // release any remaining pending sockets     

   while (m_pendingList.Head())
   {
      ReleaseSocket(m_pendingList.Head());
   }

   // destroy all free sockets

   while (m_freeList.Head())
   {
      DestroySocket(m_freeList.PopNode());
   }
}

void CSocketServerEx::StartAcceptingConnections()
{
   if (m_listeningSocket == INVALID_SOCKET)
   {
      //lint -e{1933} call to unqualified virtual function
      OnStartAcceptingConnections();

      //lint -e{1933} call to unqualified virtual function
      m_listeningSocket = CreateListeningSocket(m_address, m_port);
   
      if (!CMSWinSock::LoadAcceptEx(m_listeningSocket))
      {
         //lint -e{1933} call to unqualified virtual function
         OnError(_T("CSocketServerEx::StartAcceptingConnections() - LoadAcceptEx failed"));
      }

      if (!CMSWinSock::CanDisconnectSocketForReuse(m_listeningSocket))
      {
         //lint -e{1933} call to unqualified virtual function
         OnError(_T("CSocketServerEx::StartAcceptingConnections() - CanDisconnectSocketForReuse failed"));
      }

      // danger will robbinson... note we're not really passing a pSocket here..
      m_iocp.AssociateDevice(reinterpret_cast<HANDLE>(m_listeningSocket), (ULONG_PTR)m_listeningSocket);

      m_stopAcceptingConnectionsEvent.Reset();
      m_acceptConnectionsEvent.Set();
   }
}

void CSocketServerEx::StopAcceptingConnections()
{
   if (m_listeningSocket != INVALID_SOCKET)
   {
      m_acceptConnectionsEvent.Reset();
      m_stopAcceptingConnectionsEvent.Set();

      if (0 != ::closesocket(m_listeningSocket))
      {
         //lint -e{1933} call to unqualified virtual function
         OnError(_T("CSocketServerEx::StopAcceptingConnections() - closesocket - ") + GetLastErrorMessage(::WSAGetLastError()));
      }

      m_listeningSocket = INVALID_SOCKET;

      //lint -e{1933} call to unqualified virtual function
      OnStopAcceptingConnections();
   }
}

void CSocketServerEx::InitiateShutdown()
{
   // signal that the dispatch thread should shut down all worker threads and then exit

   StopAcceptingConnections();

   {
      CCriticalSection::Owner lock(m_listManipulationSection);

      Socket *pSocket = m_activeList.Head();

      while (pSocket)
      {
         Socket *pNext = SocketList::Next(pSocket);

         pSocket->AbortiveClose();
   
         pSocket = pNext;
      }
   }

   m_shutdownEvent.Set();

      //lint -e{1933} call to unqualified virtual function
   OnShutdownInitiated();
}

void CSocketServerEx::WaitForShutdownToComplete()
{
   // if we havent already started a shut down, do so...

   InitiateShutdown();

   Wait();

   ReleaseSockets();
   Flush();
}

SOCKET CSocketServerEx::CreateListeningSocket(
   unsigned long address,
   unsigned short port)
{
   SOCKET s = ::WSASocket(AF_INET, SOCK_STREAM, IPPROTO_IP, NULL, 0, WSA_FLAG_OVERLAPPED); 

   if (s == INVALID_SOCKET)
   {
      throw CWin32Exception(_T("CSocketServerEx::CreateListeningSocket()"), ::WSAGetLastError());
   }

   CSocket listeningSocket(s);

   CSocket::InternetAddress localAddress(address, port);

   listeningSocket.Bind(localAddress);

   listeningSocket.Listen(5);

   return listeningSocket.Detatch();
}

CSocketServerEx::WorkerThread *CSocketServerEx::CreateWorkerThread(
   CIOCompletionPort &iocp)
{
   return new WorkerThread(*this, iocp);
}

int CSocketServerEx::Run()
{
   try
   {
      vector<WorkerThread *> workers;
      
      workers.reserve(m_numThreads);
      
      for (size_t i = 0; i < m_numThreads; ++i)
      {
         //lint -e{1933} call to unqualified virtual function
         WorkerThread *pThread = CreateWorkerThread(m_iocp); 

         workers.push_back(pThread);

         pThread->Start();
      }

      HANDLE handlesToWaitFor[2];

      handlesToWaitFor[0] = m_shutdownEvent.GetEvent();
      handlesToWaitFor[1] = m_acceptConnectionsEvent.GetEvent();
      
      while (!m_shutdownEvent.Wait(0))
      {
         DWORD waitResult = ::WaitForMultipleObjects(2, handlesToWaitFor, false, INFINITE);

         if (waitResult == WAIT_OBJECT_0)
         {
            // Time to shutdown
            break;
         }
         else if (waitResult == WAIT_OBJECT_0 + 1)
         {
            if (SOCKET_ERROR == WSAEventSelect(m_listeningSocket, m_acceptEvent.GetEvent(), FD_ACCEPT))
            {
               //lint -e{1933} call to unqualified virtual function
               OnError(_T("CSocketServerEx::Run() - WSAEventSelect: ") + GetLastErrorMessage(::WSAGetLastError()));
            }

            size_t acceptsToPost =  m_acceptsToPost;

            bool checkPendingConnections = false;

            do
            {
               // accept connections

               // post X accepts on the socket and then wait for either of the events, or
               // the 'need more accepts' event

               while (m_acceptsPending < acceptsToPost)
               {
                  Accept();
               }

               m_postMoreAcceptsEvent.Reset();
               m_acceptEvent.Reset();

               if (checkPendingConnections)
               {
                  CheckPendingConnections();

                  checkPendingConnections = false;

                  if (m_acceptsPending < acceptsToPost)
                  {
                     acceptsToPost = m_acceptsToPost;
                  }
               }

               //lint -e{578} Declaration of symbol hides symbol at outer scope
               HANDLE handlesToWaitFor[4];

               handlesToWaitFor[0] = m_shutdownEvent.GetEvent();
               handlesToWaitFor[1] = m_stopAcceptingConnectionsEvent.GetEvent();
               handlesToWaitFor[2] = m_postMoreAcceptsEvent.GetEvent();
               handlesToWaitFor[3] = m_acceptEvent.GetEvent();

               waitResult = ::WaitForMultipleObjects(4, handlesToWaitFor, false, INFINITE);

               if (waitResult != WAIT_OBJECT_0 &&
                   waitResult != WAIT_OBJECT_0 + 1 &&
                   waitResult != WAIT_OBJECT_0 + 2 &&
                   waitResult != WAIT_OBJECT_0 + 3)
               {
                  //lint -e{1933} call to unqualified virtual function
                  OnError(_T("CSocketServerEx::Run() - WaitForMultipleObjects: ") + GetLastErrorMessage(::GetLastError()));
               }

               if (waitResult == WAIT_OBJECT_0 + 3)
               {
                  Output(_T("Accept..."));

                  checkPendingConnections = true;

                  acceptsToPost = acceptsToPost + 10;
               }
            }
            while (waitResult == WAIT_OBJECT_0 + 2 || waitResult == WAIT_OBJECT_0 + 3);
         }
         else
         {
            //lint -e{1933} call to unqualified virtual function
            OnError(_T("CSocketServerEx::Run() - WaitForMultipleObjects: ") + GetLastErrorMessage(::GetLastError()));
         }
      }

      for (i = 0; i < m_numThreads; ++i)
      {
         workers[i]->InitiateShutdown();
      }  

      for (i = 0; i < m_numThreads; ++i)
      {
         workers[i]->WaitForShutdownToComplete();

         delete workers[i];

         workers[i] = 0;
      }  
   }
   catch(const CException &e)
   {
      //lint -e{1933} call to unqualified virtual function
      OnError(_T("CSocketServerEx::Run() - Exception: ") + e.GetWhere() + _T(" - ") + e.GetMessage());
   }
   catch(...)
   {
      //lint -e{1933} call to unqualified virtual function
      OnError(_T("CSocketServerEx::Run() - Unexpected exception"));
   }

   //lint -e{1933} call to unqualified virtual function
   OnShutdownComplete();

   return 0;
}

SOCKET CSocketServerEx::CreateAcceptSocket()
{
   return ::WSASocket(AF_INET, SOCK_STREAM, IPPROTO_IP, NULL, 0, WSA_FLAG_OVERLAPPED);
}

size_t CSocketServerEx::GetAddressSize() const
{
   return sizeof(SOCKADDR_IN);
}

CSocketServerEx::Socket *CSocketServerEx::AllocateSocket()
{
   CCriticalSection::Owner lock(m_listManipulationSection);

   Socket *pSocket = 0;

   if (!m_freeList.Empty())
   {
      pSocket = m_freeList.PopNode();

      pSocket->AddRef();

      if (pSocket->m_socket == INVALID_SOCKET)
      {
         pSocket->Attach(CreateAcceptSocket());
      }
      else
      {
         pSocket->Initialise();
      }
   }
   else
   {
      //lint -e{1933} call to unqualified virtual function
      pSocket = new Socket(*this, CreateAcceptSocket(), m_useSequenceNumbers);

      m_iocp.AssociateDevice(reinterpret_cast<HANDLE>(pSocket->m_socket), (ULONG_PTR)pSocket);

      //lint -e{1933} call to unqualified virtual function
      OnConnectionCreated();
   }

   return pSocket;
}

void CSocketServerEx::ReleaseSocket(Socket *pSocket)
{
   if (!pSocket)
   {
      throw CException(_T("CSocketServerEx::ReleaseSocket()"), _T("pSocket is null"));
   }

   CCriticalSection::Owner lock(m_listManipulationSection);

   pSocket->RemoveFromList();

   if (m_maxFreeSockets == 0 || 
       m_freeList.Count() < m_maxFreeSockets)
   {
      m_freeList.PushNode(pSocket);
   }
   else
   {
      DestroySocket(pSocket);
   }
}

void CSocketServerEx::DestroySocket(
   Socket *pSocket)
{
   pSocket->CancelAccept();

   delete pSocket;

   //lint -e{1933} call to unqualified virtual function
   OnConnectionDestroyed();
}

void CSocketServerEx::CheckPendingConnections()
{
   Output(_T("CSocketServerEx::CheckPendingConnections()"));

   CCriticalSection::Owner lock(m_listManipulationSection);

   Socket *pSocket = m_pendingList.Head();

   while (pSocket)
   {
      Socket *pNext = SocketList::Next(pSocket);
      
      int connectTime = pSocket->GetConnectTime();

      Output(_T("Connect time: ") + ToString(connectTime));

      if (Socket::IsConnected(connectTime))
      {
         if (connectTime > (int)m_acceptReadTimeoutSeconds)
         {
            Output(_T("Closing socket, timedout waiting for data"));

            pSocket->CancelAccept();
         }
      }

      pSocket = pNext;
   }
}

void CSocketServerEx::Accept()
{
   Output(_T("CSocketServerEx::Accept()"));

   Socket *pSocket = AllocateSocket();

   {
      CCriticalSection::Owner lock(m_listManipulationSection);

      m_pendingList.PushNode(pSocket);

      ::InterlockedIncrement(&m_acceptsPending);
   }

   // allocate a buffer
   CIOBuffer *pBuffer = Allocate();

   pBuffer->SetOperation(IO_Accept_Completed);

   pBuffer->SetUserPtr(pSocket);

   //lint -e{1933} call to unqualified virtual function
   const size_t sizeOfAddress = GetAddressSize() + 16;
   const size_t sizeOfAddresses = 2 * sizeOfAddress;

   size_t bufferSize = 0;

   if (m_readDataOnAccept)
   {
      bufferSize = pBuffer->GetSize() - sizeOfAddresses;
   }

   DWORD bytesReceived = 0;

   if (!CMSWinSock::AcceptEx(
      m_listeningSocket,
      pSocket->m_socket,
      reinterpret_cast<void*>(const_cast<BYTE*>(pBuffer->GetBuffer())),
      bufferSize,
      sizeOfAddress,
      sizeOfAddress,
      &bytesReceived,
      pBuffer))
   {
      const DWORD lastError = ::WSAGetLastError();

      if (ERROR_IO_PENDING != lastError)
      {
         Output(_T("CSocketServerEx::Accept() - AcceptEx: ") + GetLastErrorMessage(lastError));

         pSocket->Release();           
         pBuffer->Release();
      }
   }
   else
   {
      // Accept completed synchronously. We need to marshal the data recieved over to the 
      // worker thread ourselves...

      m_iocp.PostStatus((ULONG_PTR)m_listeningSocket, bytesReceived, pBuffer);
   }
}

CIOBuffer *CSocketServerEx::AcceptCompleted(
   Socket *pSocket,
   CIOBuffer *pBuffer,
   DWORD dwIoSize)
{
   // Move the socket from the pending accept list to the active list

   if (Socket::IsConnected(pSocket->GetConnectTime()))
   {
      {
         CCriticalSection::Owner lock(m_listManipulationSection);

         pSocket->RemoveFromList();

         m_activeList.PushNode(pSocket);

         ::InterlockedDecrement(&m_acceptsPending);
      }

      m_postMoreAcceptsEvent.Set();

      pSocket->m_bAccepted = true;
   
      if (SOCKET_ERROR == ::setsockopt(
         pSocket->m_socket,
         SOL_SOCKET,
         SO_UPDATE_ACCEPT_CONTEXT,
         (char *)&m_listeningSocket,
         sizeof(m_listeningSocket)))
      {
         //lint -e{1933} call to unqualified virtual function
         OnError(_T("CSocketServerEx::AcceptCompleted) - setsockopt - ") + GetLastErrorMessage(::WSAGetLastError()));
      }
   
      // need to deblock the addresses into a new buffer

      //lint -e{1933} call to unqualified virtual function
      const size_t sizeOfAddress = GetAddressSize() + 16;
      const size_t sizeOfAddresses = 2 * sizeOfAddress;

      size_t bufferSize = 0;

      if (m_readDataOnAccept)
      {
         bufferSize = pBuffer->GetSize() - sizeOfAddresses;
      }

      CIOBuffer *pAddress = pBuffer->AllocateNewBuffer();  

      INT sizeOfLocalAddress = 0;
      INT sizeOfRemoteAddress = 0;

      SOCKADDR *pLocalAddress = 0;
      SOCKADDR *pRemoteAddress = 0;

      CMSWinSock::GetAcceptExSockaddrs(
         reinterpret_cast<void*>(const_cast<BYTE*>(pBuffer->GetBuffer())), 
         bufferSize,
         sizeOfAddress,
         sizeOfAddress,
         &pLocalAddress,
         &sizeOfLocalAddress,
         &pRemoteAddress,
         &sizeOfRemoteAddress);

      pAddress->AddData(reinterpret_cast<BYTE*>(pRemoteAddress), sizeOfRemoteAddress);

      //lint -e{1933} call to unqualified virtual function
      OnConnectionEstablished(pSocket, pAddress);

      pAddress->Release();
      // now we need to process any data that was read in...

      // there's now a race condition here if we have handed both the above off to a business logic
      // thread pool, they may occur out of sequence...
   }

   return pBuffer;
}

void CSocketServerEx::OnError(
   const _tstring &message)
{
   Output(message);
}
  
void CSocketServerEx::WriteCompleted(
   Socket * /*pSocket*/,
   CIOBuffer *pBuffer)
{
   if (pBuffer->GetUsed() != pBuffer->GetWSABUF()->len)
   {
      OnError(_T("CSocketServerEx::WriteCompleted - Socket write where not all data was written"));
   }

   //lint -e{818} pointer pBuffer could be declared const (but not in derived classes...)
}

void CSocketServerEx::SetServerDataPtr(
   Socket *pSocket,
   void *pData)
{
   pSocket->SetServerDataPtr(pData);
}

void *CSocketServerEx::GetServerDataPtr(
   Socket *pSocket)
{
   return pSocket->GetServerDataPtr();
}

void CSocketServerEx::WriteCompleted(
   Socket *pSocket)
{
   pSocket->WriteCompleted();
}

bool CSocketServerEx::FilterReadRequest(
   Socket *pSocket,
   CIOBuffer **ppBuffer)
{
   // Normal processing here is to return a filtered buffer if we can filter in place or false if 
   // the filtered data will be returned via a call to PostFilteredReadRequest

   return true;
}

bool CSocketServerEx::FilterReadCompleted(
   Socket *pSocket,
   CIOBuffer **ppBuffer)
{
   // Normal processing here is to return a filtered buffer if we can filter in place or false if 
   // the filtered data will be returned via a call to PostFilteredReadCompleted

   return true;
}

bool CSocketServerEx::FilterWriteRequest(
   Socket *pSocket,
   CIOBuffer **ppBuffer)
{
   // Normal processing here is to return a filtered buffer if we can filter in place or false if 
   // the filtered data will be returned via a call to PostFilteredWriteRequest

   return true;
}

bool CSocketServerEx::FilterWriteCompleted(
   Socket *pSocket,
   CIOBuffer **ppBuffer)
{
   // Normal processing here is to return a filtered buffer if we can filter in place or false if 
   // the filtered data will be returned via a call to PostFilteredWriteCompleted

   return true;
}

bool CSocketServerEx::FilterSocketShutdown(
   Socket *pSocket,
   int how)
{
   return true;
}

bool CSocketServerEx::FilterSocketClose(
   Socket *pSocket)
{
   return true;
}

void CSocketServerEx::PostFilteredReadRequest(
   Socket *pSocket,
   CIOBuffer *pBuffer)
{
   PostIoOperation(pSocket, pBuffer, IO_Filtered_Read_Request);
}

void CSocketServerEx::PostFilteredReadCompleted(
   Socket *pSocket,
   CIOBuffer *pBuffer)
{
   pBuffer->SetSequenceNumber(pSocket->GetSequenceNumber(Socket::FilteredReadSequenceNo));
   
   PostIoOperation(pSocket, pBuffer, IO_Filtered_Read_Completed);
}

void CSocketServerEx::PostFilteredWriteRequest(
   Socket *pSocket,
   CIOBuffer *pBuffer)
{
   if (pSocket->WritePending())
   {
      pBuffer->SetSequenceNumber(pSocket->GetSequenceNumber(Socket::FilteredWriteSequenceNo));

      PostIoOperation(pSocket, pBuffer, IO_Filtered_Write_Request);
   }
}

void CSocketServerEx::PostFilteredWriteCompleted(
   Socket *pSocket,
   CIOBuffer *pBuffer)
{
   PostIoOperation(pSocket, pBuffer, IO_Filtered_Write_Completed);
}

void CSocketServerEx::PostIoOperation(
   Socket *pSocket,
   CIOBuffer *pBuffer,
   IO_Operation operation)
{
   pBuffer->SetOperation(operation);
   pBuffer->AddRef();

   pSocket->AddRef();

   m_iocp.PostStatus((ULONG_PTR)pSocket, 0, pBuffer);
}


///////////////////////////////////////////////////////////////////////////////
// CSocketServerEx::Socket
///////////////////////////////////////////////////////////////////////////////

CSocketServerEx::Socket::Socket(
   CSocketServerEx &server,                                 
   SOCKET theSocket,
   bool useSequenceNumbers)
   :  m_server(server),
      m_socket(theSocket),
      m_ref(1),
      m_outstandingWrites(0),
      m_readShutdown(false),
      m_writeShutdown(false),
      m_closing(false),
      m_clientClosed(false),
      m_bAccepted(false),
      m_pSequenceData(0)
{
   if (INVALID_SOCKET == m_socket)
   {
      throw CException(_T("CSocketServerEx::Socket::Socket()"), _T("Invalid socket"));
   }

   if (useSequenceNumbers)
   {
      m_pSequenceData = new SequenceData(m_server.m_listManipulationSection);
   }
}

CSocketServerEx::Socket::~Socket()
{
   delete m_pSequenceData;
}

void CSocketServerEx::Socket::Attach(
   SOCKET theSocket)
{
   if (INVALID_SOCKET != m_socket)
   {
      throw CException(_T("CSocketServerEx::Socket::Attach()"), _T("Socket already attached"));
   }

   m_socket = theSocket;

   Initialise();
}

void CSocketServerEx::Socket::Initialise()
{
   SetUserData(0);

   m_outstandingWrites = 0;
   m_readShutdown = false;
   m_writeShutdown = false;
   m_closing = false;
   m_clientClosed = false;
   m_bAccepted = false;

   if (m_pSequenceData)
   {
      m_pSequenceData->Reset();
   }
}

CIOBuffer *CSocketServerEx::Socket::AcceptCompleted(
   CIOBuffer *pBuffer,
   DWORD dwIoSize)
{
   return m_server.AcceptCompleted(this, pBuffer, dwIoSize);
}

void CSocketServerEx::Socket::AddRef()
{
   //lint -e{534} Ignoring return value of function
   ::InterlockedIncrement(&m_ref);
}

void CSocketServerEx::Socket::Release()
{
   if (0 == ::InterlockedDecrement(&m_ref))
   {
      if (INVALID_SOCKET != m_socket && m_bAccepted)
      {
         AddRef();
      
         if (!m_closing)
         {
            m_closing = true;

            if (!m_server.OnConnectionClosing(this))
            {
               AbortiveClose();
            }
         }
         else
         {
            AbortiveClose();
         }

         Release();
         return;
      }

      m_server.ReleaseSocket(this);
   }
}

void CSocketServerEx::Socket::Shutdown(
   int how /* = SD_BOTH */)
{
   Output(_T("CSocketServer::Socket::Shutdown() ") + ToString(how));

   if (how == SD_RECEIVE || how == SD_BOTH)
   {
      m_readShutdown = true;
   }

   if (how == SD_SEND || how == SD_BOTH)
   {
      m_writeShutdown = true;
   }

   if (::InterlockedExchange(&m_outstandingWrites, m_outstandingWrites) > 0)
   {
      // Send side will be shut down when last pending write completes...

      if (how == SD_BOTH)
      {
         how = SD_RECEIVE;      
      }
      else if (how == SD_SEND)
      {
         return;
      }
   }

   if (INVALID_SOCKET != m_socket)
   {
      if (0 != ::shutdown(m_socket, how))
      {
         m_server.OnError(_T("CSocketServer::Server::Shutdown() - ") + GetLastErrorMessage(::WSAGetLastError()));
      }

      Output(_T("shutdown initiated"));
   }
}

void CSocketServerEx::Socket::DisconnectForReuse()
{
   CCriticalSection::Owner lock(m_server.m_listManipulationSection);

   if (INVALID_SOCKET != m_socket)
   {
      if (m_bAccepted) 
      {
         m_readShutdown = true;
         m_writeShutdown = true;

         m_bAccepted = false;

         CIOBuffer *pBuffer = m_server.AllocateBuffer();

         pBuffer->SetOperation(IO_Disconnect_Completed);

         AddRef();

         if (!CMSWinSock::DisconnectSocketForReuse(m_socket, pBuffer))
         {
            DWORD lastError = ::WSAGetLastError();

            if (ERROR_IO_PENDING != lastError)
            {
               m_server.OnError(_T("CSocket::Socket::DisconnectForReuse() - DisconnectSocketForReuse - ") + GetLastErrorMessage(::WSAGetLastError()));
               Release();
               pBuffer->Release();
            }
         }
         else
         {
            // Disconnect completed synchronously. We need to marshal the data recieved over to the 
            // worker thread ourselves...

            m_server.m_iocp.PostStatus((ULONG_PTR)this, 0, pBuffer);
         }
      }
   }
}

void CSocketServerEx::Socket::DisconnectCompleted()
{
   m_server.OnConnectionClosed(this);
}

void CSocketServerEx::Socket::Close()
{
   DisconnectForReuse();
}

void CSocketServerEx::Socket::CancelAccept()
{
   // Force an abortive close.

   LINGER lingerStruct;

   lingerStruct.l_onoff = 1;
   lingerStruct.l_linger = 0;

   if (SOCKET_ERROR == ::setsockopt(m_socket, SOL_SOCKET, SO_LINGER, (char *)&lingerStruct, sizeof(lingerStruct)))
   {
      //lint -e{1933} call to unqualified virtual function
      m_server.OnError(_T("CSocketServerEx::CloseSocket() - setsockopt(SO_LINGER) - ")  + GetLastErrorMessage(::WSAGetLastError()));
   }

   CCriticalSection::Owner lock(m_server.m_listManipulationSection);

   if (INVALID_SOCKET != m_socket)
   {
      if (0 != ::closesocket(m_socket))
      {
         m_server.OnError(_T("CSocket::Socket::Close() - closesocket - ") + GetLastErrorMessage(::WSAGetLastError()));
      }

      m_socket = INVALID_SOCKET;

      m_readShutdown = true;
      m_writeShutdown = true;

      m_bAccepted = false;
   }
}


bool CSocketServerEx::Socket::WritePending()
{
   if (m_writeShutdown)
   {
      Output(_T("CSocketServer::Socket::WritePending() - Attempt to write after write shutdown"));
      
      return false;
   }
   
   ::InterlockedIncrement(&m_outstandingWrites);

   return true;
}

void CSocketServerEx::Socket::WriteCompleted()
{
   if (::InterlockedDecrement(&m_outstandingWrites) == 0)
   {
      if (m_writeShutdown)
      {
         // The final pending write has been completed so we can now shutdown the send side of the
         // connection.

         Shutdown(SD_SEND);
      }
   }
}

void CSocketServerEx::Socket::AbortiveClose()
{
   // Force an abortive close.

   LINGER lingerStruct;

   lingerStruct.l_onoff = 1;
   lingerStruct.l_linger = 0;

   if (SOCKET_ERROR == ::setsockopt(m_socket, SOL_SOCKET, SO_LINGER, (char *)&lingerStruct, sizeof(lingerStruct)))
   {
      m_server.OnError(_T("CSocketServer::Socket::AbortiveClose() - setsockopt(SO_LINGER) - ")  + GetLastErrorMessage(::WSAGetLastError()));
   }

   Close();
}

void CSocketServerEx::Socket::Read(
   CIOBuffer *pBuffer /* = 0 */)
{
   // Post a read request to the iocp so that the actual socket read gets performed by
   // one of the server's IO threads...

   if (!pBuffer)
   {
      pBuffer = m_server.Allocate();
   }
   else
   {
      pBuffer->AddRef();
   }

   m_server.PostIoOperation(this, pBuffer, m_server.m_postZeroByteReads ? IO_Zero_Byte_Read_Request : IO_Read_Request);

   pBuffer->Release();
}

void CSocketServerEx::Socket::Write(
   const char *pData, 
   size_t dataLength)
{
   Write(reinterpret_cast<const BYTE*>(pData), dataLength);
}

void CSocketServerEx::Socket::Write(
   const BYTE *pData, 
   size_t dataLength)
{
   if (!WritePending())
   {
      return;
   }

   CIOBuffer *pBuffer = m_server.Allocate();

   pBuffer->AddData(pData, dataLength);

   pBuffer->SetSequenceNumber(GetSequenceNumber(WriteSequenceNo));

   m_server.PostIoOperation(this, pBuffer, IO_Write_Request);

   pBuffer->Release();
}

void CSocketServerEx::Socket::Write(
   CIOBuffer *pBuffer)
{
   if (!WritePending())
   {
      return;
   }

   pBuffer->SetSequenceNumber(GetSequenceNumber(WriteSequenceNo));

   m_server.PostIoOperation(this, pBuffer, IO_Write_Request);
}

int CSocketServerEx::Socket::GetConnectTime() const
{
   if (INVALID_SOCKET != m_socket)
   {
      INT seconds;
      INT bytes = sizeof(seconds);
   
      if (NO_ERROR == ::getsockopt(
         m_socket, 
         SOL_SOCKET, SO_CONNECT_TIME,
         (char *)&seconds, 
         (PINT)&bytes))
      {
         return seconds;
      }
      else
      {
         m_server.OnError(_T("CSocketServerEx::Socket::GetConnectTime() - getsockopt - ") + GetLastErrorMessage(::WSAGetLastError()));
      }
   }

   //lint -e{569} Loss of information (return) (32 bits to 31 bits)
   return 0xFFFFFFFF;
}

bool CSocketServerEx::Socket::IsConnected(int connectTime)
{
   return (unsigned int)connectTime != 0xFFFFFFFF;
}

void CSocketServerEx::Socket::OnClientClose()
{
   if (0 == ::InterlockedExchange(&m_clientClosed, 1))
   {
      Shutdown(SD_RECEIVE);
   
      m_server.OnConnectionClientClose(this);
   }
}


long CSocketServerEx::Socket::GetSequenceNumber(
   SequenceType type)
{
   if (m_pSequenceData)
   {
      return m_pSequenceData->m_numbers[type]++;
   }

   return 0;
}

CIOBuffer *CSocketServerEx::Socket::GetNextBuffer(
   CIOBuffer *pBuffer /* = 0 */)
{
   if (m_pSequenceData)
   {
      if (pBuffer)
      {
         return m_pSequenceData->m_outOfSequenceWrites.GetNext(pBuffer);
      }
      else
      {
         return m_pSequenceData->m_outOfSequenceWrites.ProcessAndGetNext();
      }
   }

   return pBuffer;
}

///////////////////////////////////////////////////////////////////////////////
// CSocketServerEx::Socket::SequenceData
///////////////////////////////////////////////////////////////////////////////

CSocketServerEx::Socket::SequenceData::SequenceData(
   CCriticalSection &section)
   :  m_outOfSequenceWrites(section)
{
   memset(m_numbers, 0, sizeof(m_numbers));
}

void CSocketServerEx::Socket::SequenceData::Reset()
{
   memset(m_numbers, 0, sizeof(m_numbers));

   m_outOfSequenceWrites.Reset();
}

///////////////////////////////////////////////////////////////////////////////
// CSocketServerEx::WorkerThread
///////////////////////////////////////////////////////////////////////////////

CSocketServerEx::WorkerThread::WorkerThread(
   CSocketServerEx &server,
   CIOCompletionPort &iocp)
   :  m_server(server),
      m_iocp(iocp)
{
   m_server.OnThreadCreated();
}

CSocketServerEx::WorkerThread::~WorkerThread()
{
   m_server.OnThreadDestroyed();
}

int CSocketServerEx::WorkerThread::Run()
{
   try
   {
      //lint -e{716} while(1)
      while (true)   
      {
         // continually loop to service io completion packets

         DWORD dwIoSize = 0;
         Socket *pSocket = 0;
         CIOBuffer *pBuffer = 0;
         
         try
         {
            m_iocp.GetStatus((PDWORD_PTR)&pSocket, &dwIoSize, (OVERLAPPED**)&pBuffer);
         }
         catch (const CWin32Exception &e)
         {
            if (e.GetError() != ERROR_NETNAME_DELETED &&
                e.GetError() != WSA_OPERATION_ABORTED)
            {
               throw;
            }
            
            Output(_T("IOCP error - client connection dropped"));
         }

         if (!pSocket)
         {
            // A completion key of 0 is posted to the iocp to request us to shut down...

            break;
         }

         m_server.OnThreadBeginProcessing();

         HandleOperation(pSocket, pBuffer, dwIoSize);

         m_server.OnThreadEndProcessing();
      } 
   }
   catch(const CException &e)
   {
      m_server.OnError(_T("CSocketServerEx::WorkerThread::Run() - Exception: ") + e.GetWhere() + _T(" - ") + e.GetMessage());
   }
   catch(...)
   {
      m_server.OnError(_T("CSocketServerEx::WorkerThread::Run() - Unexpected exception"));
   }

   return 0;
}

void CSocketServerEx::WorkerThread::InitiateShutdown()
{
   m_iocp.PostStatus(0);         
}

void CSocketServerEx::WorkerThread::WaitForShutdownToComplete()
{
   // if we havent already started a shut down, do so...

   InitiateShutdown();

   Wait();
}

void CSocketServerEx::WorkerThread::HandleOperation(
   Socket *pSocket,
   CIOBuffer *pBuffer,
   DWORD dwIoSize) 
{
   if (pBuffer)
   {
      const IO_Operation operation = static_cast<IO_Operation>(pBuffer->GetOperation());

      switch (operation)
      {
         case IO_Accept_Completed :

            AcceptCompleted(pBuffer, dwIoSize);

            pBuffer->Release();

         break;

         case IO_Disconnect_Completed :

            pSocket->DisconnectCompleted();

            pSocket->Release();
            pBuffer->Release();

         break;

         case IO_Zero_Byte_Read_Request :

            ZeroByteRead(pSocket, pBuffer);

            pSocket->Release();
            pBuffer->Release();

         break ;

         case IO_Zero_Byte_Read_Completed :
         case IO_Read_Request :

            if (m_server.FilterReadRequest(pSocket, &pBuffer))
            {
               Read(pSocket, pBuffer);
            }
            
            pSocket->Release();
            pBuffer->Release();

         break;
   
         case IO_Filtered_Read_Request :

            Read(pSocket, pBuffer);

            pSocket->Release();
            pBuffer->Release();

         break;

         case IO_Read_Completed :

            pBuffer->Use(dwIoSize);
            
            Output(_T("  RX: ") + ToString(pBuffer->GetUsed()) + _T(" bytes") + _T(" Seq: ") + ToString(pBuffer->GetSequenceNumber()) + _T(" : ") + ToString(pBuffer) + _T("\n"));
            //DEBUG_ONLY(Output(_T("  RX: ") + ToString(pBuffer->GetUsed()) + _T(" bytes") + _T(" Seq: ") + ToString(pBuffer->GetSequenceNumber()) + _T(" : ") + ToString(pBuffer) + _T("\n") + DumpData(reinterpret_cast<const BYTE*>(pBuffer->GetWSABUF()->buf), dwIoSize, 40)));
            
            if (m_server.FilterReadCompleted(pSocket, &pBuffer))
            {
               if (0 != dwIoSize)
               {
                  //DEBUG_ONLY(Output(_T("  RX: ") + ToString(pBuffer) + _T("\n") + DumpData(reinterpret_cast<const BYTE*>(pBuffer->GetWSABUF()->buf), dwIoSize, 40)));

                  m_server.ReadCompleted(pSocket, pBuffer);
               }
            }

            if (0 == dwIoSize)
            {
               // client connection dropped?

               Output(_T("ReadCompleted - 0 bytes - client connection dropped"));

               pSocket->OnClientClose();
            }

            pSocket->Release();
            pBuffer->Release();

         break;

         case IO_Filtered_Read_Completed :
            
            //DEBUG_ONLY(Output(_T("F RX: ") + ToString(pBuffer->GetUsed()) + _T(" bytes") + _T(" Seq: ") + ToString(pBuffer->GetSequenceNumber()) + _T(" : ") + ToString(pBuffer) + _T("\n") + DumpData(reinterpret_cast<const BYTE*>(pBuffer->GetBuffer()), pBuffer->GetUsed(), 40)));

            if (0 != pBuffer->GetUsed())     // post the correct io size
            {
               m_server.ReadCompleted(pSocket, pBuffer);
            }
            
            pSocket->Release();
            pBuffer->Release();

         break;

         case IO_Write_Request :

            Output(_T("  TX: ") + ToString(pBuffer->GetUsed()) + _T(" bytes") + _T(" Seq: ") + ToString(pBuffer->GetSequenceNumber()) + _T(" : ") + ToString(pBuffer) + _T("\n"));
            //DEBUG_ONLY(Output(_T("  TX: ") + ToString(pBuffer->GetUsed()) + _T(" bytes") + _T(" Seq: ") + ToString(pBuffer->GetSequenceNumber()) + _T(" : ") + ToString(pBuffer) + _T("\n") + DumpData(reinterpret_cast<const BYTE*>(pBuffer->GetBuffer()), pBuffer->GetUsed(), 40)));

            if (m_server.FilterWriteRequest(pSocket, &pBuffer))
            {
               //CCriticalSection::Owner lock(pSocket->m_server.m_listManipulationSection);

               //pBuffer->SetSequenceNumber(pSocket->GetSequenceNumber(Socket::FilteredWriteSequenceNo));

               Write(pSocket, pBuffer);
            }

            pSocket->Release();
            pBuffer->Release();

         break;

         case IO_Filtered_Write_Request :

            //DEBUG_ONLY(Output(_T("F TX: ") + ToString(pBuffer->GetUsed()) + _T(" bytes") + _T(" Seq: ") + ToString(pBuffer->GetSequenceNumber()) + _T(" : ") + ToString(pBuffer) + _T("\n") + DumpData(reinterpret_cast<const BYTE*>(pBuffer->GetBuffer()), pBuffer->GetUsed(), 40)));

            Write(pSocket, pBuffer);

            pSocket->Release();
            pBuffer->Release();

         break;

         case IO_Write_Completed :

            pBuffer->Use(dwIoSize);

            if (m_server.FilterWriteCompleted(pSocket, &pBuffer))
            {
               m_server.WriteCompleted(pSocket, pBuffer);

               pSocket->WriteCompleted();
            }

            pSocket->Release();
            pBuffer->Release();

         break;

         case IO_Filtered_Write_Completed :

            m_server.WriteCompleted(pSocket, pBuffer);

            pSocket->WriteCompleted();

            pSocket->Release();
            pBuffer->Release();

         break;

         default :
            m_server.OnError(_T("CSocketServer::WorkerThread::Run() - Unexpected operation"));
         break;
      } 
   }
   else
   {
      m_server.OnError(_T("CSocketServer::WorkerThread::Run() - Unexpected - pBuffer is 0"));
   }
}

void CSocketServerEx::WorkerThread::AcceptCompleted(
   CIOBuffer *pBuffer,
   DWORD dwIoSize)
{
   Socket *pSocket = reinterpret_cast<Socket*>(pBuffer->GetUserPtr());

   pBuffer = pSocket->AcceptCompleted(pBuffer, dwIoSize);

   if (0 != dwIoSize)
   {
      pBuffer->Use(dwIoSize);

      //lint -e{1933} call to unqualified virtual function
      m_server.ReadCompleted(pSocket, pBuffer);
   }

   pSocket->Release();
}

void CSocketServerEx::WorkerThread::ZeroByteRead(
   Socket *pSocket,
   CIOBuffer *pBuffer) const
{
   pSocket->AddRef();

   pBuffer->SetOperation(IO_Zero_Byte_Read_Completed);
   pBuffer->SetupZeroByteRead();
   pBuffer->AddRef();

   DWORD dwNumBytes = 0;
   DWORD dwFlags = 0;

   if (SOCKET_ERROR == ::WSARecv(
      pSocket->m_socket, 
      pBuffer->GetWSABUF(), 
      1, 
      &dwNumBytes,
      &dwFlags,
      pBuffer, 
      NULL))
   {
      DWORD lastError = ::WSAGetLastError();

      if (ERROR_IO_PENDING != lastError)
      {
         if (WSAESHUTDOWN == lastError)
         {
            pSocket->OnClientClose();
         }
         else
         {
            Output(_T("CSocketServer::ZeroByteRead() - WSARecv: ") + GetLastErrorMessage(lastError));
         }
         
         pSocket->Release();
         pBuffer->Release();
      }
   }
}

void CSocketServerEx::WorkerThread::Read(
   Socket *pSocket,
   CIOBuffer *pBuffer) const
{
   pSocket->AddRef();

   pBuffer->SetOperation(IO_Read_Completed);
   pBuffer->SetupRead();
   pBuffer->AddRef();

   CCriticalSection::Owner lock(pSocket->m_server.m_listManipulationSection);

   pBuffer->SetSequenceNumber(pSocket->GetSequenceNumber(Socket::ReadSequenceNo));

   DWORD dwNumBytes = 0;
   DWORD dwFlags = 0;

   if (SOCKET_ERROR == ::WSARecv(
      pSocket->m_socket, 
      pBuffer->GetWSABUF(), 
      1, 
      &dwNumBytes,
      &dwFlags,
      pBuffer, 
      NULL))
   {
      DWORD lastError = ::WSAGetLastError();

      if (ERROR_IO_PENDING != lastError)
      {
         if (WSAESHUTDOWN == lastError)
         {
            pSocket->OnClientClose();
         }
         else
         {
            Output(_T("CSocketServer::Read() - WSARecv: ") + GetLastErrorMessage(lastError));
         }
         
         pSocket->Release();
         pBuffer->Release();
      }
   }
}

void CSocketServerEx::WorkerThread::Write(
   Socket *pSocket,
   CIOBuffer *pBuffer) const
{
   pSocket->AddRef();

   pBuffer->SetOperation(IO_Write_Completed);
   pBuffer->SetupWrite();
   pBuffer->AddRef();

   pBuffer = pSocket->GetNextBuffer(pBuffer);

   while(pBuffer)
   {
      Output(_T("X TX: Seq: ") + ToString(pBuffer->GetSequenceNumber()));

      DWORD dwFlags = 0;
      DWORD dwSendNumBytes = 0;

      if (SOCKET_ERROR == ::WSASend(
         pSocket->m_socket,
         pBuffer->GetWSABUF(), 
         1, 
         &dwSendNumBytes,
         dwFlags,
         pBuffer, 
         NULL))
      {
         DWORD lastError = ::WSAGetLastError();

         if (ERROR_IO_PENDING != lastError)
         {
            Output(_T("CSocketServer::WorkerThread::Write() - WSASend: ") + GetLastErrorMessage(lastError));

            pSocket->WriteCompleted();  // this pending write will never complete...

            pSocket->Release();
            pBuffer->Release();
         }
      }

      pBuffer = pSocket->GetNextBuffer();
   }
}


///////////////////////////////////////////////////////////////////////////////
// Static helper methods
///////////////////////////////////////////////////////////////////////////////

static size_t CalculateNumberOfThreads(size_t numThreads)
{
   if (numThreads == 0)
   {
      CSystemInfo systemInfo;
   
      numThreads = systemInfo.dwNumberOfProcessors * 2;
   }

   return numThreads;
}

///////////////////////////////////////////////////////////////////////////////
// Namespace: JetByteTools::Win32
///////////////////////////////////////////////////////////////////////////////

} // End of namespace Win32
} // End of namespace JetByteTools 

///////////////////////////////////////////////////////////////////////////////
// Lint options
//
//lint -restore
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// End of file...
///////////////////////////////////////////////////////////////////////////////
