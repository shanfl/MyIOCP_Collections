#if defined (_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

#ifndef JETBYTE_TOOLS_WIN32_SOCKET_SERVER_EX_INCLUDED__
#define JETBYTE_TOOLS_WIN32_SOCKET_SERVER_EX_INCLUDED__
///////////////////////////////////////////////////////////////////////////////
//
// File           : $Workfile: SocketServerEx.h $
// Version        : $Revision: 7 $
// Function       : 
//
// Author         : $Author: Len $
// Date           : $Date: 19/07/02 11:21 $
//
// Notes          : 
//
// Modifications  :
//
// $Log: /Web Articles/SocketServers/EchoServerEx/JetByteTools/Win32Tools/SocketServerEx.h $
// 
// 7     19/07/02 11:21 Len
// Merged in changes from latest Socket Server code.
// 
// 6     1/07/02 12:31 Len
// Moved all callbacks to the SocketServer class. We now provide a default
// implementation for the WorkerThread. This raises its events via the
// socket server. The user now only has to provide one derived class
// rather than two. We now provide a default implementation for listening
// socket creation.
// 
// 5     29/06/02 6:46 Len
// Reset socket flags when reusing socket
// 
// 4     29/06/02 5:13 Len
// Integrated the socket closure changes from the non EX version of the
// socket server.
// 
// 3     29/05/02 11:16 Len
// Lint issues.
// 
// 2     29/05/02 10:07 Len
// Refactored the socket connection time stuff.
// 
// 1     28/05/02 15:09 Len
// 
///////////////////////////////////////////////////////////////////////////////
//
// Copyright 1997 - 2002 JetByte Limited.
//
// JetByte Limited grants you ("Licensee") a non-exclusive, royalty free, 
// licence to use, modify and redistribute this software in source and binary 
// code form, provided that i) this copyright notice and licence appear on all 
// copies of the software; and ii) Licensee does not utilize the software in a 
// manner which is disparaging to JetByte Limited.
//
// This software is provided "as is" without a warranty of any kind. All 
// express or implied conditions, representations and warranties, including
// any implied warranty of merchantability, fitness for a particular purpose
// or non-infringement, are hereby excluded. JetByte Limited and its licensors 
// shall not be liable for any damages suffered by licensee as a result of 
// using, modifying or distributing the software or its derivatives. In no
// event will JetByte Limited be liable for any lost revenue, profit or data,
// or for direct, indirect, special, consequential, incidental or punitive
// damages, however caused and regardless of the theory of liability, arising 
// out of the use of or inability to use software, even if JetByte Limited 
// has been advised of the possibility of such damages.
//
// This software is not designed or intended for use in on-line control of 
// aircraft, air traffic, aircraft navigation or aircraft communications; or in 
// the design, construction, operation or maintenance of any nuclear 
// facility. Licensee represents and warrants that it will not use or 
// redistribute the Software for such purposes. 
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// Lint options
//
//lint -save
//
//lint -esym(1509, CUsesWinsock) Base class destructor not virtual
//
// Data member hides inherited member
//lint -esym(1516, Allocator::m_activeList)
//lint -esym(1516, Allocator::m_freeList)
//
// Private constructor
//lint -esym(1704, CSocketServerEx::CSocketServerEx)
//lint -esym(1704, Socket::Socket)
//lint -esym(1704, WorkerThread::WorkerThread)
//
// No default constructor
//lint -esym(1712, CSocketServerEx)
//lint -esym(1712, Socket)
//lint -esym(1712, WorkerThread)
//
// Class member is a reference
//lint -esym(1725, Socket::m_server)
//lint -esym(1725, WorkerThread::m_iocp)
//
///////////////////////////////////////////////////////////////////////////////

#include "UsesWinsock.h"
#include "Thread.h"
#include "CriticalSection.h"
#include "IOCompletionPort.h"
#include "IOBuffer.h"
#include "ManualResetEvent.h"

#include "NodeList.h"
#include "OpaqueUserData.h"

///////////////////////////////////////////////////////////////////////////////
// Namespace: JetByteTools::Win32
///////////////////////////////////////////////////////////////////////////////

namespace JetByteTools {
namespace Win32 {

///////////////////////////////////////////////////////////////////////////////
// CSocketServerEx
///////////////////////////////////////////////////////////////////////////////

class CSocketServerEx : 
   protected CThread, 
   private CUsesWinsock, 
   protected CIOBuffer::Allocator
{
   public:

      class Socket;

      friend class Socket;

      virtual ~CSocketServerEx();

      using CThread::Start;

      void StartAcceptingConnections();
      void StopAcceptingConnections();

      void InitiateShutdown();

      void WaitForShutdownToComplete();

   protected :

      class WorkerThread;

      friend class WorkerThread;

      CSocketServerEx(
         unsigned long addressToListenOn,
         unsigned short portToListenOn,
         size_t maxFreeSockets,
         size_t maxFreeBuffers,
         size_t acceptsToPost,
         bool readDataOnAccept,
         size_t acceptReadTimeoutSeconds = 5,
         size_t bufferSize = 1024,
         size_t numThreads = 0,
         bool useSequenceNumbers = true,
         bool postZeroByteReads = false);

      void PostFilteredReadRequest(
         Socket *pSocket,
         CIOBuffer *pBuffer);

      void PostFilteredReadCompleted(
         Socket *pSocket,
         CIOBuffer *pBuffer);

      void PostFilteredWriteRequest(
         Socket *pSocket,
         CIOBuffer *pBuffer);

      void PostFilteredWriteCompleted(
         Socket *pSocket,
         CIOBuffer *pBuffer);

      void SetServerDataPtr(
         Socket *pSocket,
         void *pData);

      void *GetServerDataPtr(
         Socket *pSocket);

      void WriteCompleted(
         Socket *pSocket);

   private :

      class UserData;
      class ServerData;

      virtual int Run();

      // Override this to create your worker thread

      virtual WorkerThread *CreateWorkerThread(
         CIOCompletionPort &iocp);

      // Override this to create the listening socket of your choice

      virtual SOCKET CreateListeningSocket(
         unsigned long address,
         unsigned short port);

      virtual SOCKET CreateAcceptSocket();

      virtual size_t GetAddressSize() const;

      // Interface for derived classes to receive state change notifications...

      virtual void OnStartAcceptingConnections() {}
      virtual void OnStopAcceptingConnections() {}
      virtual void OnShutdownInitiated() {}
      virtual void OnShutdownComplete() {}

      virtual void OnConnectionCreated() {}

      virtual void OnConnectionEstablished(
         Socket *pSocket,
         CIOBuffer *pAddress) = 0;
      
      virtual void OnConnectionClientClose(
          Socket * /*pSocket*/) {}

      virtual bool OnConnectionClosing(
         Socket * /*pSocket*/) { return false; }

      virtual void OnConnectionClosed(
         Socket * /*pSocket*/) {}

      virtual void OnConnectionDestroyed() {}

      virtual void OnError(
         const _tstring &message);

      virtual void OnBufferCreated() {}
      virtual void OnBufferAllocated() {}
      virtual void OnBufferReleased() {}
      virtual void OnBufferDestroyed() {}

      virtual void OnThreadCreated() {}
      virtual void OnThreadBeginProcessing() {}
      virtual void OnThreadEndProcessing() {}
      virtual void OnThreadDestroyed() {}

      virtual bool FilterReadRequest(
         Socket *pSocket,
         CIOBuffer **ppBuffer);

      virtual bool FilterReadCompleted(
         Socket *pSocket,
         CIOBuffer **ppBuffer);

      virtual bool FilterWriteRequest(
         Socket *pSocket,
         CIOBuffer **ppBuffer);

      virtual bool FilterWriteCompleted(
         Socket *pSocket,
         CIOBuffer **ppBuffer);

      virtual bool FilterSocketShutdown(
         Socket *pSocket,
         int how);

      virtual bool FilterSocketClose(
         Socket *pSocket);

      virtual void ReadCompleted(
         Socket *pSocket,
         CIOBuffer *pBuffer) = 0;

      virtual void WriteCompleted(
         Socket *pSocket,
         CIOBuffer *pBuffer);

      Socket *AllocateSocket();

      void ReleaseSockets();

      void ReleaseSocket(
         Socket *pSocket);

      void DestroySocket(
         Socket *pSocket);

      void Accept();

      CIOBuffer *AcceptCompleted(
         Socket *pSocket,
         CIOBuffer *pBuffer,
         DWORD dwIoSize);

      void CheckPendingConnections();

      CIOBuffer *AllocateBuffer()
      {
         return Allocate();
      }

      enum IO_Operation 
      { 
         IO_Accept_Completed,
         IO_Disconnect_Completed,
         IO_Zero_Byte_Read_Request,
         IO_Zero_Byte_Read_Completed,
         IO_Read_Request, 
         IO_Read_Completed, 
         IO_Write_Request, 
         IO_Write_Completed,
         IO_Filtered_Read_Request,
         IO_Filtered_Read_Completed, 
         IO_Filtered_Write_Request, 
         IO_Filtered_Write_Completed
      };

      void PostIoOperation(
         Socket *pSocket,
         CIOBuffer *pBuffer,
         IO_Operation operation);

      const size_t m_numThreads;

      CCriticalSection m_listManipulationSection;

      typedef JetByteTools::TNodeList<Socket> SocketList;

      SocketList m_activeList;
      SocketList m_freeList;
      SocketList m_pendingList;

      SOCKET m_listeningSocket;

      CIOCompletionPort m_iocp;

      CManualResetEvent m_shutdownEvent;
      CManualResetEvent m_acceptConnectionsEvent;
      CManualResetEvent m_postMoreAcceptsEvent;
      CManualResetEvent m_stopAcceptingConnectionsEvent;
      CManualResetEvent m_acceptEvent;

      const unsigned long m_address;
      const unsigned short m_port;

      const size_t m_maxFreeSockets;

      const size_t m_acceptsToPost;
      long m_acceptsPending;

      const size_t m_acceptReadTimeoutSeconds;

      const bool m_readDataOnAccept;

      const bool m_useSequenceNumbers;

      const bool m_postZeroByteReads;

      // No copies do not implement
      CSocketServerEx(const CSocketServerEx &rhs);
      CSocketServerEx &operator=(const CSocketServerEx &rhs);
};

///////////////////////////////////////////////////////////////////////////////
// CSocketServerEx::UserData
///////////////////////////////////////////////////////////////////////////////

class CSocketServerEx::UserData : public COpaqueUserData
{
   // UserData is a shim class that allows Socket to inherit from two 
   // COpaqueUserData bases without ambiguity
};

///////////////////////////////////////////////////////////////////////////////
// CSocketServerEx::ServerData
///////////////////////////////////////////////////////////////////////////////

class CSocketServerEx::ServerData : public COpaqueUserData
{
   // ServerData is a shim class that allows Socket to inherit from two 
   // COpaqueUserData bases without ambiguity
};
///////////////////////////////////////////////////////////////////////////////
// CSocketServerEx::Socket
///////////////////////////////////////////////////////////////////////////////

class CSocketServerEx::Socket : 
   public CNodeList::Node, 
   public CSocketServerEx::UserData, 
   protected CSocketServerEx::ServerData
{
   public :

      friend class CSocketServerEx;
      friend class CSocketServerEx::WorkerThread;

      using UserData::SetUserData;
      using UserData::GetUserData;
      using UserData::SetUserPtr;
      using UserData::GetUserPtr;

      void Read(
         CIOBuffer *pBuffer = 0);

      void Write(
         const char *pData, 
         size_t dataLength);

      void Write(
         const BYTE *pData, 
         size_t dataLength);

      void Write(
         CIOBuffer *pBuffer);

      void AddRef();
      void Release();

      void Shutdown(
         int how = SD_BOTH);

      void Close();

      void AbortiveClose();

      int GetConnectTime() const;

      static bool IsConnected(
         int connectTime);

   private :

      Socket(
         CSocketServerEx &server,                                 
         SOCKET socket,
         bool useSequenceNumbers);

      ~Socket();

      void Attach(
         SOCKET socket);

      void *GetServerDataPtr() const
      {
         return ServerData::GetUserPtr();
      }

      void SetServerDataPtr(void *pData)
      {
         ServerData::SetUserPtr(pData);
      }

      void Initialise();

      CIOBuffer *AcceptCompleted(
         CIOBuffer *pBuffer,
         DWORD dwIoSize);

      void DisconnectCompleted();

      void WriteCompleted();
      bool WritePending();

      void OnClientClose();

      void DisconnectForReuse();

      void CancelAccept();

      CSocketServerEx &m_server;
      SOCKET m_socket;

      long m_ref;

      long m_outstandingWrites;

      // TODO we could store all of these 1 bit flags in with the outstanding write count..

      bool m_readShutdown;       
      bool m_writeShutdown;
      bool m_closing;
      long m_clientClosed;       
      bool m_bAccepted;

      enum SequenceType 
      {
         ReadSequenceNo,
         WriteSequenceNo,
         FilteredReadSequenceNo,
         FilteredWriteSequenceNo,
         MaxSequenceNo
      };

      long GetSequenceNumber(
         SequenceType type);

      CIOBuffer *GetNextBuffer(
         CIOBuffer *pBuffer = 0);

      struct SequenceData
      {
         SequenceData(
            CCriticalSection &section);

         void Reset();

         long m_numbers[4];

         CIOBuffer::InOrderBufferList m_outOfSequenceWrites;
      };

      SequenceData *m_pSequenceData;

      // No copies do not implement
      Socket(const Socket &rhs);
      Socket &operator=(const Socket &rhs);
};

///////////////////////////////////////////////////////////////////////////////
// CSocketServerEx::WorkerThread
///////////////////////////////////////////////////////////////////////////////

class CSocketServerEx::WorkerThread : public CThread
{
   public :

      WorkerThread(
         CSocketServerEx &server,
         CIOCompletionPort &iocp);

      virtual ~WorkerThread();

      void InitiateShutdown();

      void WaitForShutdownToComplete();

   protected :

      //lint -e{1768} Virtual function has different access specifier to base class
      virtual int Run();

      virtual void HandleOperation(
         Socket *pSocket,
         CIOBuffer *pBuffer,
         DWORD dwIoSize);

   private :

      void AcceptCompleted(
         CIOBuffer *pBuffer,
         DWORD dwIoSize);

      void ZeroByteRead(
         Socket *pSocket,
         CIOBuffer *pBuffer) const;

      void Read(
         Socket *pSocket,
         CIOBuffer *pBuffer) const;

      void Write(
         Socket *pSocket,
         CIOBuffer *pBuffer) const;

      CSocketServerEx &m_server;
      CIOCompletionPort &m_iocp;

      // No copies do not implement
      WorkerThread(const WorkerThread &rhs);
      WorkerThread &operator=(const WorkerThread &rhs);
};

///////////////////////////////////////////////////////////////////////////////
// Namespace: JetByteTools::Win32
///////////////////////////////////////////////////////////////////////////////

} // End of namespace Win32
} // End of namespace JetByteTools 

///////////////////////////////////////////////////////////////////////////////
// Lint options
//
//lint -restore
//
///////////////////////////////////////////////////////////////////////////////

#endif // JETBYTE_TOOLS_WIN32_SOCKET_SERVER_EX_INCLUDED__

///////////////////////////////////////////////////////////////////////////////
// End of file
///////////////////////////////////////////////////////////////////////////////

