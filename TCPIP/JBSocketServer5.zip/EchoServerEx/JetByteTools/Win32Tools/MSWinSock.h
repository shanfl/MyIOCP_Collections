#if defined (_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

#ifndef JETBYTE_TOOLS_WIN32_MS_WINSOCK_EXTENSIONS_INCLUDED__
#define JETBYTE_TOOLS_WIN32_MS_WINSOCK_EXTENSIONS_INCLUDED__
///////////////////////////////////////////////////////////////////////////////
//
// File           : $Workfile: MSWinSock.h $
// Version        : $Revision: 4 $
// Function       : 
//
// Author         : $Author: Len $
// Date           : $Date: 29/06/02 5:13 $
//
// Notes          : 
//
// Modifications  :
//
// $Log: /Web Articles/SocketServers/EchoServerEx/JetByteTools/Win32Tools/MSWinSock.h $
// 
// 4     29/06/02 5:13 Len
// Allow DisconnectSocketForReuse() to be called async.
// 
// 3     29/05/02 11:16 Len
// Lint issues.
// 
// 2     29/05/02 9:22 Len
// Fixed exceptions.
// 
// 1     28/05/02 15:09 Len
// 
///////////////////////////////////////////////////////////////////////////////
//
// Copyright 1997 - 2002 JetByte Limited.
//
// JetByte Limited grants you ("Licensee") a non-exclusive, royalty free, 
// licence to use, modify and redistribute this software in source and binary 
// code form, provided that i) this copyright notice and licence appear on all 
// copies of the software; and ii) Licensee does not utilize the software in a 
// manner which is disparaging to JetByte Limited.
//
// This software is provided "as is" without a warranty of any kind. All 
// express or implied conditions, representations and warranties, including
// any implied warranty of merchantability, fitness for a particular purpose
// or non-infringement, are hereby excluded. JetByte Limited and its licensors 
// shall not be liable for any damages suffered by licensee as a result of 
// using, modifying or distributing the software or its derivatives. In no
// event will JetByte Limited be liable for any lost revenue, profit or data,
// or for direct, indirect, special, consequential, incidental or punitive
// damages, however caused and regardless of the theory of liability, arising 
// out of the use of or inability to use software, even if JetByte Limited 
// has been advised of the possibility of such damages.
//
// This software is not designed or intended for use in on-line control of 
// aircraft, air traffic, aircraft navigation or aircraft communications; or in 
// the design, construction, operation or maintenance of any nuclear 
// facility. Licensee represents and warrants that it will not use or 
// redistribute the Software for such purposes. 
//
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// Lint options
//
//lint -save
//
//lint -esym(1704, Exception::Exception) private constructor
//lint -esym(1712, Exception) no default constructor
//
//lint -e537   repeated include, winsock2.h
///////////////////////////////////////////////////////////////////////////////

#include <winsock2.h>

#include "Exception.h"

#include <mswsock.h>

///////////////////////////////////////////////////////////////////////////////
// Namespace: JetByteTools::Win32
///////////////////////////////////////////////////////////////////////////////

namespace JetByteTools {
namespace Win32 {

///////////////////////////////////////////////////////////////////////////////
// CMSWinSock
///////////////////////////////////////////////////////////////////////////////

class CMSWinSock 
{
   public:

      class Exception;

      static bool AcceptEx(
         SOCKET listenSocket,
         SOCKET acceptSocket,
         PVOID pOutputBuffer,
         DWORD receiveDataLength,
         DWORD localAddressLength,
         DWORD remoteAddressLength,
         LPDWORD bytesReceived,
         LPOVERLAPPED pOverlapped);

      static bool LoadAcceptEx(
         SOCKET s);

      static void GetAcceptExSockaddrs(
         PVOID pOutputBuffer,       
         DWORD receiveDataLength,  
         DWORD localAddressLength,  
         DWORD remoteAddressLength,  
         LPSOCKADDR *pLocalSockaddr,  
         LPINT pLocalSockaddrLength,  
         LPSOCKADDR *pRemoteSockaddr,  
         LPINT pRemoteSockaddrLength);

      static bool LoadGetAcceptExSockaddrs(
         SOCKET s);

      static bool DisconnectEx(
         SOCKET s,
         LPOVERLAPPED pOverlapped,
         DWORD flags);

      static bool LoadDisconnectEx(
         SOCKET s);

      static bool TransmitFile(
         SOCKET s,
         HANDLE fileToTransmit,
         DWORD numberOfBytesToWrite,
         DWORD numberOfBytesPerSend,
         LPOVERLAPPED pOverlapped,
         LPTRANSMIT_FILE_BUFFERS lTransmitBuffers,
         DWORD flags);

      static bool LoadTransmitFile(
         SOCKET s);

      static bool DisconnectSocketForReuse(
         SOCKET s,
         LPOVERLAPPED pOverlapped);

      static bool CanDisconnectSocketForReuse(
         SOCKET s);

   private :

      static LPFN_ACCEPTEX pAcceptEx;
      static LPFN_GETACCEPTEXSOCKADDRS pGetAcceptExSockaddrs;
      static LPFN_DISCONNECTEX pDisconnectEx;
      static LPFN_TRANSMITFILE pTransmitFile;
};

///////////////////////////////////////////////////////////////////////////////
// CMSWinSock::Exception
///////////////////////////////////////////////////////////////////////////////

class CMSWinSock::Exception : public CException
{
   friend class CMSWinSock;

   private :

      Exception(
         const _tstring &where, 
         const _tstring &what);
};

///////////////////////////////////////////////////////////////////////////////
// Namespace: JetByteTools::Win32
///////////////////////////////////////////////////////////////////////////////

} // End of namespace Win32
} // End of namespace JetByteTools 

///////////////////////////////////////////////////////////////////////////////
// Lint options
//
//lint -restore
//
///////////////////////////////////////////////////////////////////////////////

#endif // JETBYTE_TOOLS_WIN32_MS_WINSOCK_EXTENSIONS_INCLUDED__

///////////////////////////////////////////////////////////////////////////////
// End of file
///////////////////////////////////////////////////////////////////////////////

