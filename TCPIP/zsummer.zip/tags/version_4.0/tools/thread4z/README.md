thread4z
========

thread4z 是一款开源的C++轻量级跨平台线程库.  

auther: 张亚伟 
=======  
QQ Group: 19811947  
Web Site: www.zsummer.net  
mail: yawei_zhang@foxmail.com  
github: https://github.com/zsummer  
