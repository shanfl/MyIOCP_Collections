log4z  
==========  
Log4z is an open source C++ lightweight log library.  
It provides in a C++ application log and trace debug function.   
  
The advantages of log4z  
1.  MIT open source license,very liberal.  
2. lightweight and cross platform.  
3. complete priority level control.  
4. multi log output,  thread safe.  
5. complete file's configure.  
6. display to screen with different color.  
  
  
log4z  
==========  
log4z 是一款开源的C++轻量级日志库. 他提供了在C++程序中使用日志和跟踪调试的功能.  

log4z的优点  
1. MIT开源授权 无限制使用.  
2. 轻量级, 跨平台 可在linux与windows上共同使用.  
3. 完整的日志优先级控制.  
4. 多日志分流 线程安全.  
5. 可通过配置文件全程配置.  
6. 屏幕日志为彩色输出, 信息简约整洁.  



auther: 张亚伟 
=======  
QQ Group: 19811947  
Web Site: www.zsummer.net  
mail: yawei_zhang@foxmail.com  
github: https://github.com/zsummer  








